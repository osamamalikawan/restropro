"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

type NavItem = { href: string; label: string; roles?: string[] };
type NavGroup = { label: string; items: NavItem[] };

const NAV_GROUPS: NavGroup[] = [
  {
    label: "Operate",
    items: [
      { href: "/dashboard", label: "Dashboard" },
      { href: "/pos", label: "Point of Sale" },
    ],
  },
  {
    label: "Manage",
    items: [
      { href: "/dashboard/customers", label: "Customers" },
      { href: "/dashboard/menu", label: "Menu" },
      { href: "/dashboard/inventory", label: "Inventory" },
      { href: "/dashboard/restock", label: "Restock" },
      { href: "/dashboard/suppliers", label: "Suppliers" },
      { href: "/dashboard/supplier-ledger", label: "Supplier Ledger" },
      { href: "/dashboard/employee-ledger", label: "Employee Ledger" },
      { href: "/dashboard/accounts", label: "Accounts" },
      { href: "/dashboard/expenses", label: "Expenses" },
    ],
  },
  {
    label: "Configure",
    items: [{ href: "/dashboard/tables-delivery", label: "Tables & Delivery" }],
  },
  {
    label: "System",
    items: [
      { href: "/dashboard/settings", label: "Settings", roles: ["admin"] },
      { href: "/dashboard/permissions", label: "Users & Permissions", roles: ["admin"] },
    ],
  },
];

export function Sidebar({ role }: { role: string }) {
  const pathname = usePathname();

  return (
    <aside className="w-60 shrink-0 border-r border-neutral-800 bg-neutral-900 p-4 hidden md:flex md:flex-col overflow-y-auto">
      <div className="mb-6 px-2">
        <div className="font-display text-lg font-semibold">Restro Pro</div>
        <div className="text-[10px] text-neutral-500 uppercase tracking-wide">Ops Console</div>
      </div>
      {NAV_GROUPS.map((group) => {
        const visibleItems = group.items.filter((i) => !i.roles || i.roles.includes(role));
        if (visibleItems.length === 0) return null;
        return (
          <div key={group.label} className="mb-5">
            <div className="text-[10px] uppercase tracking-wide text-neutral-600 font-semibold px-2 mb-2">{group.label}</div>
            {visibleItems.map((item) => {
              const active = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`block rounded-md px-2.5 py-2 text-sm mb-0.5 transition-colors ${
                    active ? "bg-chili-500/15 text-chili-400 font-semibold" : "text-neutral-400 hover:bg-neutral-800 hover:text-neutral-100"
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </div>
        );
      })}
    </aside>
  );
}
