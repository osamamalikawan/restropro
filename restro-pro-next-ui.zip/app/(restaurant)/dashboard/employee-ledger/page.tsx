import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { verifyStaffSessionToken, STAFF_SESSION_COOKIE } from "@/lib/auth/staff-session";
import { EmployeeLedgerClient } from "./employee-ledger-client";

export default async function EmployeeLedgerPage() {
  const token = cookies().get(STAFF_SESSION_COOKIE)?.value;
  const session = await verifyStaffSessionToken(token);
  if (!session) redirect("/login");
  if (session.role !== "admin" && session.role !== "manager") redirect("/dashboard");

  return <EmployeeLedgerClient />;
}
