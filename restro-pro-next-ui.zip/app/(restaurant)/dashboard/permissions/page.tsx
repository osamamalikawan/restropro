import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { verifyStaffSessionToken, STAFF_SESSION_COOKIE } from "@/lib/auth/staff-session";
import { PermissionsClient } from "./permissions-client";

export default async function PermissionsPage() {
  const token = cookies().get(STAFF_SESSION_COOKIE)?.value;
  const session = await verifyStaffSessionToken(token);
  if (!session) redirect("/login");
  if (session.role !== "admin") redirect("/dashboard");

  return <PermissionsClient />;
}
