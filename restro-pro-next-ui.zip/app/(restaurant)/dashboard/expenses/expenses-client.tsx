"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

type Expense = {
  id: string;
  category: string;
  expense_type: "regular" | "recurring";
  amount: number;
  vendor: string | null;
  description: string | null;
  payment_method: string;
  txn_date: string;
};

const DEFAULT_CATEGORIES = ["Utilities", "Rent", "Maintenance", "Marketing", "Salaries", "Other"];

export function ExpensesClient() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [category, setCategory] = useState(DEFAULT_CATEGORIES[0]);
  const [expenseType, setExpenseType] = useState<"regular" | "recurring">("regular");
  const [amount, setAmount] = useState("");
  const [vendor, setVendor] = useState("");
  const [description, setDescription] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("Cash");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    const res = await fetch("/api/expenses");
    const data = await res.json();
    if (res.ok) setExpenses(data.expenses ?? []);
  }
  useEffect(() => {
    load();
  }, []);

  const totalThisList = expenses.reduce((s, e) => s + e.amount, 0);

  async function addExpense() {
    if (!category || !amount) return;
    setSaving(true);
    setError("");
    const res = await fetch("/api/expenses", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        category,
        expenseType,
        amount: Number(amount),
        vendor: vendor.trim() || undefined,
        description: description.trim() || undefined,
        paymentMethod,
      }),
    });
    setSaving(false);
    if (!res.ok) {
      setError((await res.json()).error);
      return;
    }
    setAmount("");
    setVendor("");
    setDescription("");
    load();
  }

  return (
    <main className="min-h-screen bg-neutral-950 text-neutral-50 p-6 md:p-8 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-2xl font-semibold">Expenses</h1>
        <Link href="/dashboard" className="text-xs text-neutral-400 underline hover:text-neutral-200">
          ← Dashboard
        </Link>
      </div>

      <div className="rounded-xl border border-neutral-800 bg-neutral-900 p-4 mb-6">
        <div className="text-xs text-neutral-500 uppercase">Total (last 50 entries)</div>
        <div className="text-crimson-400 font-semibold text-lg">Rs {totalThisList}</div>
      </div>

      <div className="rounded-xl border border-neutral-800 bg-neutral-900 p-5 mb-6">
        <h2 className="font-display font-semibold mb-3">Log expense</h2>
        {error && <p className="text-crimson-400 text-sm mb-2">{error}</p>}
        <div className="grid grid-cols-2 gap-2 mb-2">
          <select value={category} onChange={(e) => setCategory(e.target.value)} className="rounded-md bg-neutral-800 border border-neutral-700 px-3 py-2 text-sm">
            {DEFAULT_CATEGORIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
          <select value={expenseType} onChange={(e) => setExpenseType(e.target.value as "regular" | "recurring")} className="rounded-md bg-neutral-800 border border-neutral-700 px-3 py-2 text-sm">
            <option value="regular">Regular</option>
            <option value="recurring">Recurring</option>
          </select>
        </div>
        <div className="grid grid-cols-2 gap-2 mb-2">
          <input value={amount} onChange={(e) => setAmount(e.target.value)} type="number" placeholder="Amount" className="rounded-md bg-neutral-800 border border-neutral-700 px-3 py-2 text-sm" />
          <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)} className="rounded-md bg-neutral-800 border border-neutral-700 px-3 py-2 text-sm">
            <option>Cash</option>
            <option>Card</option>
            <option>Bank Transfer</option>
          </select>
        </div>
        <div className="grid grid-cols-2 gap-2 mb-3">
          <input value={vendor} onChange={(e) => setVendor(e.target.value)} placeholder="Vendor (optional)" className="rounded-md bg-neutral-800 border border-neutral-700 px-3 py-2 text-sm" />
          <input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description (optional)" className="rounded-md bg-neutral-800 border border-neutral-700 px-3 py-2 text-sm" />
        </div>
        <button onClick={addExpense} disabled={saving} className="rounded-md bg-chili-500 hover:bg-chili-600 disabled:opacity-50 text-white text-sm font-semibold px-4 py-2">
          {saving ? "Saving…" : "Log expense"}
        </button>
      </div>

      <div className="rounded-xl border border-neutral-800 bg-neutral-900 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-neutral-800/50 text-neutral-400 text-xs uppercase">
            <tr>
              <th className="text-left p-3">Date</th>
              <th className="text-left p-3">Category</th>
              <th className="text-left p-3">Vendor</th>
              <th className="text-left p-3">Type</th>
              <th className="text-left p-3">Amount</th>
            </tr>
          </thead>
          <tbody>
            {expenses.map((e) => (
              <tr key={e.id} className="border-t border-neutral-800">
                <td className="p-3 text-neutral-400">{e.txn_date}</td>
                <td className="p-3 font-medium">
                  {e.category}
                  {e.description ? <div className="text-xs text-neutral-500">{e.description}</div> : null}
                </td>
                <td className="p-3 text-neutral-400">{e.vendor ?? "—"}</td>
                <td className="p-3">
                  <span className={`text-xs px-2 py-1 rounded-full ${e.expense_type === "recurring" ? "bg-turmeric-500/20 text-turmeric-400" : "bg-neutral-800 text-neutral-500"}`}>
                    {e.expense_type}
                  </span>
                </td>
                <td className="p-3 font-mono text-crimson-400">Rs {e.amount}</td>
              </tr>
            ))}
            {expenses.length === 0 && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-neutral-500">
                  No expenses logged yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </main>
  );
}
